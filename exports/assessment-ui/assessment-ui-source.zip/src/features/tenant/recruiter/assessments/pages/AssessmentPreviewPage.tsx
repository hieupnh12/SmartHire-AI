import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { BookOpen, ClipboardList, FilePenLine, RotateCcw } from "lucide-react";
import type { Question } from "@/api/types/assessment";
import { Button } from "@/components/ux/Button";
import { assessmentInput, FieldError } from "@/components/ux/assessmentUi";
import { QuestionContentFields } from "../components/QuestionContentFields";
import { essayPreviewAnswer, essayPreviewBank, essayPreviewFeedback, codingPreviewAnswer } from "../constants/essayPreview";
import { CodingPreviewPanel } from "../components/CodingPreviewPanel";
import { rubricSchema, codingSchema, contentError } from "../utils/questionContentValidation";

const panel = "rounded-xl border border-[var(--color-border-default)] bg-[var(--color-surface-card)] p-5 space-y-4";
const steps = ["Ngân hàng câu hỏi", "Cấu trúc đề", "Ứng viên làm bài", "Chấm & duyệt điểm"];

export function AssessmentPreviewPage() {
  const { id } = useParams();
  const [step, setStep] = useState(2);
  const [bank, setBank] = useState<Question[]>(() => structuredClone(essayPreviewBank));
  const [selected, setSelected] = useState(9102);
  const question = bank.find(item => item.id === selected) ?? bank[1];
  const [prompt, setPrompt] = useState(essayPreviewBank[1].questionText);
  const [rubric, setRubric] = useState(JSON.stringify(essayPreviewBank[1].rubricJson));
  const [error, setError] = useState<string>();
  const [notice, setNotice] = useState("");
  const [answer, setAnswer] = useState(essayPreviewAnswer);
  const [objectiveDone, setObjectiveDone] = useState(false);
  const [option, setOption] = useState<number>();
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState("18.1");
  const [approved, setApproved] = useState<number | null>(null);
  const [source, setSource] = useState(codingPreviewAnswer);
  const [codeApproved, setCodeApproved] = useState<number | null>(null);
  const codeQuestion = bank[3];
  const reviewQuestion = bank[1];
  const totalScore = approved == null || codeApproved == null ? null : Number(((option == null || option === 1 ? 10 : 0) + 24 + approved + codeApproved).toFixed(2));
  const weights = reviewQuestion.rubricJson?.criteria ?? [];
  const suggested = Number((weights.reduce((sum, item, index) => sum + item.weight * (essayPreviewFeedback[index]?.percent ?? 0) / 100, 0) * reviewQuestion.points / 100).toFixed(2));
  const scoreValid = score.trim() !== "" && Number.isFinite(Number(score)) && Number(score) >= 0 && Number(score) <= reviewQuestion.points && /^\d+(\.\d{1,2})?$/.test(score);

  function choose(item: Question) {
    setSelected(item.id); setPrompt(item.questionText); setRubric(JSON.stringify(item.questionType === "CODING" ? item.coding : item.rubricJson)); setError(undefined); setNotice("");
  }
  function saveQuestion() {
    try {
      if (!prompt.trim()) throw new Error("Nhập nội dung câu hỏi.");
      const parsed = question.questionType === "CODING" ? { coding: codingSchema.parse(JSON.parse(rubric)) } : { rubricJson: rubricSchema.parse(JSON.parse(rubric)) };
      setBank(items => items.map(item => item.id === selected ? { ...item, questionText: prompt.trim(), ...parsed } : item));
      setApproved(null); setCodeApproved(null); setSubmitted(false); setError(undefined); setNotice("Đã lưu câu hỏi trong ngân hàng mẫu và cập nhật đề mẫu.");
    } catch (failure) { setError(failure instanceof Error && failure.message === "Nhập nội dung câu hỏi." ? failure.message : contentError(failure)); }
  }
  function approve(value: number) { setApproved(value); setNotice(`Đã duyệt ${value}/${reviewQuestion.points} điểm cho câu tự luận mẫu.`); }

  return <div className="mx-auto max-w-6xl space-y-6 p-4 sm:p-6">
    <Link to={`/recruiter/jobs/${id}/assessments`} className="text-sm text-[var(--color-primary)] hover:underline">← Quản lý bài đánh giá</Link>
    <header className="flex flex-wrap items-start justify-between gap-4">
      <div><p className="text-sm font-medium text-[var(--color-primary)]">ASSESSMENT MẪU · Java Backend Developer</p><h1 className="mt-1 text-2xl font-semibold">Xem trước trải nghiệm làm bài của ứng viên</h1><p className="mt-2 text-sm text-[var(--color-on-surface-variant)]">Thử chọn đáp án, viết tự luận và làm bài code. Chuyển các tab để xem cấu trúc đề, cách soạn câu hỏi và duyệt điểm.</p></div>
      <Button variant="secondary" onClick={() => { setBank(structuredClone(essayPreviewBank)); choose(essayPreviewBank[1]); setAnswer(essayPreviewAnswer); setObjectiveDone(false); setOption(undefined); setSubmitted(false); setApproved(null); setScore("18.1"); setSource(codingPreviewAnswer); setCodeApproved(null); setStep(2); }}><RotateCcw className="size-4" aria-hidden="true" />Đặt lại mẫu</Button>
    </header>
    <p className="rounded-lg bg-[var(--color-surface-container-low)] p-3 text-sm">Dữ liệu minh họa trong bộ nhớ, mất khi tải lại trang. Điểm và nhận xét AI bên dưới là ví dụ dựng sẵn, không đánh giá câu trả lời bạn nhập.</p>
    <nav aria-label="Các bước xem assessment mẫu" className="grid gap-2 sm:grid-cols-4">{steps.map((label, index) => <Button key={label} variant={step === index ? "primary" : "secondary"} aria-current={step === index ? "step" : undefined} onClick={() => { setStep(index); setNotice(""); }}>{index + 1}. {label}</Button>)}</nav>
    {notice && <p role="status" className="text-sm text-[var(--color-primary)]">{notice}</p>}

    {step === 0 && <div className="grid items-start gap-5 lg:grid-cols-[320px_1fr]">
      <section className={panel}><h2 className="flex items-center gap-2 font-semibold"><BookOpen className="size-5" aria-hidden="true" />Ngân hàng mẫu</h2><p className="text-sm">4 câu · 1 trắc nghiệm · 2 tự luận · 1 code</p>{bank.map(item => <button key={item.id} type="button" aria-pressed={selected === item.id} onClick={() => choose(item)} className={`w-full rounded-lg border p-3 text-left ${selected === item.id ? "border-[var(--color-primary)] bg-[var(--color-surface-container-low)]" : "border-[var(--color-border-default)]"}`}><span className="text-xs text-[var(--color-primary)]">{item.questionType} · {item.skill} · {item.points} điểm</span><span className="mt-2 block text-sm font-medium">{item.questionText}</span></button>)}</section>
      <section className={panel}><h2 className="font-semibold">Biên soạn câu #{question.id}</h2><p className="text-sm">{question.difficulty} · {question.skill} · {question.points} điểm</p>{(question.questionType === "ESSAY" || question.questionType === "CODING") ? <><label className="block text-sm">Nội dung câu hỏi<textarea rows={4} className={assessmentInput} value={prompt} onChange={event => setPrompt(event.target.value)} /></label><QuestionContentFields type={question.questionType === "CODING" ? "CODING" : "ESSAY"} value={rubric} onChange={setRubric} /><FieldError message={error} /><Button onClick={saveQuestion}>Lưu câu hỏi mẫu</Button><p className="text-xs text-[var(--color-on-surface-variant)]">Đáp án tham khảo và rubric chỉ dành cho người biên soạn/chấm bài.</p></> : <><p>{question.questionText}</p>{question.options.map(item => <p key={item.id} className="rounded-lg bg-[var(--color-surface-container-low)] p-3 text-sm">{item.optionText}{item.correct ? " · Đáp án đúng" : ""}</p>)}</>}</section>
    </div>}

    {step === 1 && <section className={panel}><h2 className="flex items-center gap-2 text-lg font-semibold"><ClipboardList className="size-5" aria-hidden="true" />Đề mẫu: Java Backend · 45 phút</h2><p className="text-sm">Ngưỡng đạt: 60/100 điểm · Trắc nghiệm tối đa 10 phút · Tổng thời gian tính từ lúc bắt đầu.</p>{["Phần 1 — Trắc nghiệm (10 điểm)", "Phần 2 — Tự luận & code (90 điểm)"].map((label, index) => <div key={label} className="space-y-3 rounded-lg bg-[var(--color-surface-container-low)] p-4"><h3 className="font-medium">{label}</h3>{bank.filter(item => index === 0 ? item.questionType === "MCQ" : item.questionType !== "MCQ").map(item => <p key={item.id} className="text-sm">{item.questionText} <strong>({item.points} điểm)</strong></p>)}</div>)}<p className="text-sm">Bản mẫu cho phép sửa để khám phá. Trong luồng thật, câu hỏi được sao chép từ ngân hàng; publish khóa đề và sửa ngân hàng không thay đổi đề đã tạo.</p><Button onClick={() => setStep(2)}>Thử màn hình ứng viên</Button></section>}

    {step === 2 && <section className={panel}><h2 className="flex items-center gap-2 text-lg font-semibold"><FilePenLine className="size-5" aria-hidden="true" />Ứng viên mẫu: Nguyễn Minh Anh</h2><p className="text-sm">{submitted ? "Đã nộp · Đang chờ chấm" : objectiveDone ? "Phần 2 · Tự luận & code" : "Phần 1 · Trắc nghiệm"} · Đồng hồ chỉ được mô tả trong bản mẫu.</p>{!objectiveDone ? <><h3 className="font-medium">{bank[0].questionText}</h3>{bank[0].options.map(item => <label key={item.id} className="flex gap-3 rounded-lg border border-[var(--color-border-default)] p-4"><input type="radio" name="preview-objective" checked={option === item.id} onChange={() => setOption(item.id)} />{item.optionText}</label>)}<p className="text-sm">Chốt phần trắc nghiệm sẽ khóa lựa chọn, sau đó mở tự luận.</p><Button disabled={option == null} onClick={() => setObjectiveDone(true)}>Chốt trắc nghiệm & chuyển tự luận</Button></> : <><h3 className="whitespace-pre-wrap font-medium">{reviewQuestion.questionText}</h3><p className="text-sm">{reviewQuestion.points} điểm · Không hiển thị đáp án mẫu hoặc rubric cho ứng viên.</p><label className="block text-sm">Bài làm (hỗ trợ nhập Markdown)<textarea rows={10} maxLength={10000} className={assessmentInput} value={answer} disabled={submitted} onChange={event => setAnswer(event.target.value)} /></label><p className="text-xs">{answer.trim().split(/\s+/).filter(Boolean).length} từ · {answer.length}/10.000 ký tự · Nháp giữ trong trang mẫu.</p><p className="text-sm">Để rút gọn thao tác, câu tự luận thứ hai có bài mẫu đã chấm 24/30 điểm.</p><CodingPreviewPanel question={codeQuestion} source={source} onSourceChange={setSource} submitted={submitted} approved={codeApproved} onApprove={setCodeApproved} /><Button disabled={submitted || !answer.trim() || !source.trim()} onClick={() => { setSubmitted(true); setApproved(null); setCodeApproved(null); setStep(3); setScore(String(suggested)); setNotice("Đã nộp bài mẫu. Nhận xét minh họa đã sẵn sàng để duyệt."); }}>Nộp bài mẫu</Button></>}</section>}

    {step === 3 && <div className="grid items-start gap-5 lg:grid-cols-[1fr_300px]">
      <section className={panel}><h2 className="text-lg font-semibold">Chấm tự luận theo rubric</h2><p className="text-sm">Bài {submitted ? "vừa nộp" : "dựng sẵn"} · {approved == null ? "Chờ recruiter duyệt" : "Đã duyệt"}</p><h3 className="font-medium">{reviewQuestion.questionText}</h3><pre className="whitespace-pre-wrap rounded-lg bg-[var(--color-surface-container-low)] p-4 font-sans text-sm">{answer}</pre><details><summary className="cursor-pointer font-medium">Đáp án tham khảo</summary><p className="mt-3 whitespace-pre-wrap text-sm">{reviewQuestion.rubricJson?.referenceAnswer}</p></details><div className="overflow-x-auto"><table className="w-full text-left text-sm"><caption className="mb-3 text-left">Đánh giá minh họa theo tiêu chí (giữ cố định khi sửa bài làm)</caption><thead><tr><th className="p-2">Tiêu chí</th><th className="p-2">Tỉ trọng</th><th className="p-2">Mức đạt</th></tr></thead><tbody>{weights.map((item, index) => <tr key={index} className="border-t border-[var(--color-border-default)]"><td className="p-2">{item.description}<p className="mt-1 text-xs text-[var(--color-on-surface-variant)]">{essayPreviewFeedback[index]?.feedback ?? "Tiêu chí thêm mới: minh họa mức đạt 0%, chưa có nhận xét mẫu."}</p></td><td className="p-2">{item.weight}%</td><td className="p-2">{essayPreviewFeedback[index]?.percent ?? 0}%</td></tr>)}</tbody></table></div><p className="text-sm">Điểm đề xuất = {reviewQuestion.points} × Σ(tỉ trọng × mức đạt) = <strong>{suggested}/{reviewQuestion.points}</strong>.</p><p className="text-sm">Trong hệ thống thật, AI đánh giá ý nghĩa theo rubric. Recruiter duyệt hoặc điều chỉnh trước khi công bố điểm tổng.</p><CodingPreviewPanel question={codeQuestion} source={source} onSourceChange={setSource} submitted={submitted} review approved={codeApproved} onApprove={setCodeApproved} /></section>
      <aside className={panel}><h2 className="font-semibold">Duyệt điểm</h2><p className="text-3xl font-semibold text-[var(--color-primary)]">{approved ?? suggested}<span className="text-base">/{reviewQuestion.points}</span></p><p className="text-sm">{approved == null ? "Điểm AI minh họa đề xuất" : "Điểm chính thức đã duyệt"}</p><Button className="w-full" onClick={() => approve(suggested)}>Chấp thuận điểm mẫu</Button><label className="block text-sm">Điểm điều chỉnh<input type="number" min={0} max={reviewQuestion.points} step="0.01" className={assessmentInput} value={score} onChange={event => setScore(event.target.value)} /></label>{!scoreValid && <FieldError message={`Nhập điểm từ 0 đến ${reviewQuestion.points}, tối đa 2 chữ số thập phân.`} />}<Button variant="secondary" className="w-full" disabled={!scoreValid} onClick={() => approve(Number(score))}>Lưu điểm điều chỉnh</Button><div className="space-y-2 border-t border-[var(--color-border-default)] pt-4"><p className="text-sm">Trắc nghiệm: {option == null || option === 1 ? 10 : 0}/10</p><p className="text-sm">Tự luận 2 (đã duyệt mẫu): 24/30</p><p className="text-sm">Code: {codeApproved == null ? "Chờ duyệt" : `${codeApproved}/40`}</p><p className="font-semibold">Tổng: {totalScore == null ? "Chờ duyệt tự luận và code" : `${totalScore}/100`}</p>{totalScore != null && <p role="status" className="text-sm">{totalScore >= 60 ? "Đạt" : "Chưa đạt"} · Ngưỡng 60 điểm</p>}</div></aside>
    </div>}
  </div>;
}
