import { useState } from "react";
import type { Question } from "@/api/types/assessment";
import { Button } from "@/components/ux/Button";
import { assessmentInput, FieldError } from "@/components/ux/assessmentUi";

export function CodingPreviewPanel({ question, source, onSourceChange, submitted, review = false, approved, onApprove }: {
  question: Question; source: string; onSourceChange: (value: string) => void; submitted: boolean;
  review?: boolean; approved: number | null; onApprove: (value: number) => void;
}) {
  const [samplesShown, setSamplesShown] = useState(false);
  const suggested = Number((question.points * (0.8 + 0.2 * 0.85)).toFixed(2));
  const [score, setScore] = useState(String(suggested));
  const valid = /^\d+(\.\d{1,2})?$/.test(score) && Number(score) <= question.points;
  return <section className="space-y-4 rounded-lg border border-[var(--color-border-default)] p-4">
    <h3 className="font-semibold">Code · {question.points} điểm · JavaScript</h3>
    <p className="whitespace-pre-wrap text-sm">{question.questionText}</p>
    <p className="text-xs">Giới hạn: {question.coding?.timeLimitMs} ms · {question.coding?.memoryMb} MB</p>
    <label className="block text-sm">Mã nguồn<textarea rows={9} maxLength={10000} className={`${assessmentInput} font-mono`} value={source} disabled={submitted || review} onChange={event => { onSourceChange(event.target.value); setSamplesShown(false); }} /></label>
    <div className="space-y-2">{question.coding?.testCases.filter(test => test.sample || review).map((test, index) => <div key={index} className="rounded-lg bg-[var(--color-surface-container-low)] p-3 text-sm"><p className="font-medium">{test.sample ? "Sample" : "Hidden"} test {index + 1}</p><pre className="overflow-x-auto whitespace-pre-wrap">Input: {test.input}{"\n"}Output mong đợi: {test.expectedOutput}</pre></div>)}</div>
    {!review && <><Button variant="secondary" disabled={submitted || !source.trim()} onClick={() => setSamplesShown(true)}>Xem kết quả chạy mẫu minh họa</Button>{samplesShown && <p role="status" className="text-sm">Ví dụ lời giải mẫu: 2/2 sample tests đạt. Đây là kết quả dựng sẵn, không thực thi mã bạn nhập.</p>}</>}
    {review && <><p className="text-sm">Kết quả minh họa cố định: 5/5 tests đạt (80%); AI review 85/100 (20%). Code rõ ràng, giữ thứ tự; có thể tối ưu để tránh tạo mảng trung gian.</p><p className="font-semibold">Đề xuất: {question.points} × (80% × 100% + 20% × 85%) = {suggested}/{question.points}</p><div className="flex flex-wrap items-end gap-3"><Button onClick={() => onApprove(suggested)}>Duyệt điểm code mẫu</Button><label className="text-sm">Điểm điều chỉnh<input type="number" min={0} max={question.points} step="0.01" className={assessmentInput} value={score} onChange={event => setScore(event.target.value)} /></label><Button variant="secondary" disabled={!valid} onClick={() => onApprove(Number(score))}>Lưu điểm code</Button></div>{!valid && <FieldError message={`Nhập điểm từ 0 đến ${question.points}, tối đa 2 chữ số thập phân.`} />}<p role="status" className="text-sm">{approved == null ? "Code đang chờ duyệt" : `Code đã duyệt: ${approved}/${question.points} điểm`}</p></>}
  </section>;
}
